# import paho.mqtt.client as mqtt
#
# mqttc = mqtt.Client("client2")
# mqttc.connect("127.0.0.1", 1883)
# mqttc.publish("camera/data", "lge 멘토링 입니다.")
import sys
from datetime import datetime
import paho.mqtt.client as mqtt
from time import sleep

def read_time():
    str_time = datetime.today().strftime("%Y/%m/%d %H:%M:%S")
    client.publish("sensors/test/time", str_time)

    sleep(2)

client = mqtt.Client("sensor_pub")
client.connect("localhost", 1883, 60)

try:
    while True:
        read_time()

except KeyboardInterrupt:
    sys.exit(0)
