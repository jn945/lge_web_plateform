from django.shortcuts import render

# Create your views here.
# 사용자 URL : http://localhost:8000/css/index - ioc callback function
def index(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/css/index")
    return render(request , 'css/index.html')

# 외부 스타일시트 적용 페이지
def external(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/css/css01")
    return render(request, 'css/css01.html')

