
from django.contrib import admin
from django.urls import path , include
from cssApp     import views


# http://localhost:8000/css
urlpatterns = [

    # http://localhost:8000/css/index/
    path('index/', views.index),

    # http://localhost:8000/css/css01/
    path('css01/', views.external),



]







