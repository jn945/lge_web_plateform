from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
# 사용자 URL : http://localhost:8000/script/index - ioc callback function

def index(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/script/index")
    return render(request , 'script/index.html')

def dom(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/script/script01")
    return render(request , 'script/script01.html')

def chart(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/script/script02")

    # user data 만들어서 심기
    data_lst = [100, 50, 150, 88, 23, 32, 256, 128, 99, 512]
    context = {'data_lst' : data_lst}

    return render(request , 'script/script02.html', context)

def ajax(request) :
    print("debug >>>>>>>> client url > http://localhost:8000/script/ajax")

    #data_lst = [100, 50, 150, 88, 23, 32, 256, 128, 99, 512]
    data_lst = []
    data_lst.append(100)
    data_lst.append(50)
    data_lst.append(150)
    data_lst.append(88)
    data_lst.append(23)
    data_lst.append(45)
    context = {'data_lst': data_lst}

    return JsonResponse(context , safe=False)