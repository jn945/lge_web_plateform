# import paho.mqtt.client as mqtt
#
# # subscriber callback
# def on_message(client, userdata, message):
#     print("message received ", str(message.payload.decode("utf-8")))
#     print("message topic=", message.topic)
#     print("message qos=", message.qos)
#     print("message retain flag=", message.retain)
#
#
# broker_address = "127.0.0.1"
# #구독자 이름
# client1 = mqtt.Client("client1")
# #broker 주소 등록
# client1.connect('localhost', 1883)
# #등록하고픈 토픽 지정
# client1.subscribe("camera/data")
# client1.on_message = on_message
# client1.loop_forever()
#
#


from datetime import datetime
import paho.mqtt.client as mqtt

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("connected OK")
    else:
        print("Bad connection Returned code=", rc)

def on_disconnect(client, userdata, flags, rc=0):
    print(str(rc))

def on_subscribe(client, userdata, mid, granted_qos):
    print("subscribed: " + str(mid) + " " + str(granted_qos))

def create_figure(header):
    print("create figure with ",header)

first_msg = 0
im = 0
def on_message(client, userdata, msg):
    print("[" + datetime.today().strftime("%Y/%m/%d %H:%M:%S") + "] topic : " + msg.topic)
    print("payload : " + str(msg.payload))

# 새로운 클라이언트 생성
client = mqtt.Client()
# 콜백 함수 설정 on_connect(브로커에 접속), on_disconnect(브로커에 접속종료), on_subscribe(topic 구독), on_message(발행된 메세지가 들어왔을 때)
client.on_connect = on_connect
client.on_disconnect = on_disconnect
client.on_subscribe = on_subscribe
client.on_message = on_message

client.connect('localhost', 1883)
client.subscribe('sensors/test/#', 1)
client.loop_forever()
